# Smart Fridge > 2025-05-20 10:57pm
https://universe.roboflow.com/smart-fridge-mvi88/smart-fridge-co7ul

Provided by a Roboflow user
License: CC BY 4.0

