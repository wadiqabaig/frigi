# fridge food images > yolo v11 model training
https://universe.roboflow.com/fridge-dataset/fridge-food-images

Provided by a Roboflow user
License: CC BY 4.0

